import json, re, hashlib, time
from pathlib import Path
import requests
from pydantic import ValidationError
from .models import ChunkExtraction

SYSTEM_PROMPT = """
You are extracting research metadata from a user-provided book excerpt about psychotherapy.
Use ONLY information supported by the excerpt. Do not reproduce long passages or copyrighted
dialogue. Paraphrase concepts in your own words. Any example_phrasing must be a short,
newly written illustrative sentence, not a quotation or close imitation of the book.

Identify:
- explicit therapeutic strategies, therapist attitudes, principles, and interventions;
- client situations, dilemmas, or case-like examples that could become scenario seeds.

Do not invent diagnoses, clinical facts, or claims absent from the excerpt. If no supported
items exist, return empty arrays. Keep source_refs exactly as the supplied source reference.
Use modality cbt_beck for Judith Beck CBT material, person_centered_rogers for Rogers material,
and cross_modality only when the excerpt genuinely supports both. Preserve the excerpt language
in descriptions where practical. Include language code from metadata.
Anxiety estimates are rough scenario-design estimates, not clinical assessments.
"""

def source_ref(chunk):
    p = chunk.get("start_page")
    q = chunk.get("end_page")
    pages = f"pp.{p}-{q}" if p and q and p != q else (f"p.{p}" if p else "page_unknown")
    return f'{chunk.get("book_file")}:{pages}:chunk={chunk["chunk_id"]}'

def normalize_id(prefix, value):
    slug = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")[:45] or "item"
    return f"{prefix}_{slug}_{hashlib.sha1(value.encode()).hexdigest()[:6]}"

def call_openai(chunk, cfg):
    from openai import OpenAI
    client = OpenAI(api_key=cfg["openai_api_key"])
    user = {
        "source_ref": source_ref(chunk),
        "book": chunk["book"],
        "language": chunk["language"],
        "excerpt": chunk["text"]
    }
    # JSON mode + Pydantic validation keeps this compatible across current chat-completions models.
    response = client.chat.completions.create(
        model=cfg["openai_model"],
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(user, ensure_ascii=False)}
        ],
        response_format={"type": "json_object"},
        temperature=0.1
    )
    return response.choices[0].message.content

def call_ollama(chunk, cfg):
    user = {
        "source_ref": source_ref(chunk),
        "book": chunk["book"],
        "language": chunk["language"],
        "excerpt": chunk["text"]
    }
    schema = ChunkExtraction.model_json_schema()
    r = requests.post(
        cfg["ollama_url"] + "/api/chat",
        json={
            "model": cfg["ollama_model"],
            "stream": False,
            "format": schema,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(user, ensure_ascii=False)}
            ],
            "options": {"temperature": 0.1}
        },
        timeout=600
    )
    r.raise_for_status()
    return r.json()["message"]["content"]

def extract_chunk(chunk, cfg, retries=3):
    if cfg["provider"] == "openai":
        if not cfg["openai_api_key"]:
            raise RuntimeError("OPENAI_API_KEY is empty. Configure .env or choose LLM_PROVIDER=ollama.")
        caller = call_openai
    elif cfg["provider"] == "ollama":
        caller = call_ollama
    else:
        raise ValueError("LLM_PROVIDER must be 'openai' or 'ollama'.")
    last = None
    for attempt in range(retries):
        try:
            raw = caller(chunk, cfg)
            data = json.loads(raw)
            result = ChunkExtraction.model_validate(data)
            ref = source_ref(chunk)
            for s in result.strategies:
                s.source_refs = list(dict.fromkeys(s.source_refs + [ref]))
                if not s.strategy_id:
                    s.strategy_id = normalize_id("strat", s.strategy_name)
            for seed in result.scenario_seeds:
                seed.source_refs = list(dict.fromkeys(seed.source_refs + [ref]))
                if not seed.seed_id:
                    seed.seed_id = normalize_id("seed", seed.title)
            # Ensure source metadata is retained even if the model omits it.
            for s in result.strategies:
                if not s.language or s.language == "und": s.language = chunk["language"]
                if not s.modality or s.modality == "uncategorized":
                    s.modality = "cbt_beck" if chunk["book"] == "beck_cbt" else "person_centered_rogers"
            for seed in result.scenario_seeds:
                if not seed.language or seed.language == "und": seed.language = chunk["language"]
            return result
        except Exception as e:
            last = e
            time.sleep(2 ** attempt)
    raise RuntimeError(f"Chunk {chunk['chunk_id']} failed after {retries} attempts: {last}")

def run_extraction(chunks_path: Path, output_dir: Path, cfg):
    chunks = [json.loads(x) for x in chunks_path.read_text(encoding="utf-8").splitlines() if x.strip()]
    if cfg["max_chunks"] > 0:
        chunks = chunks[:cfg["max_chunks"]]
    strategies, seeds, failures = [], [], []
    for i, chunk in enumerate(chunks, 1):
        print(f"[{i}/{len(chunks)}] extracting {chunk['chunk_id']} ({chunk['book']}, {chunk['language']})")
        try:
            result = extract_chunk(chunk, cfg)
            strategies.extend([x.model_dump() for x in result.strategies])
            seeds.extend([x.model_dump() for x in result.scenario_seeds])
        except Exception as e:
            failures.append({"chunk_id": chunk["chunk_id"], "error": str(e)})
            print("  ERROR:", e)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "strategies_raw.json").write_text(json.dumps(strategies, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "scenario_seeds.json").write_text(json.dumps(seeds, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "extraction_failures.json").write_text(json.dumps(failures, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Extracted {len(strategies)} strategies and {len(seeds)} seeds; failures: {len(failures)}")
