import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

def get_config():
    return {
        "provider": os.getenv("LLM_PROVIDER", "openai").lower(),
        "openai_api_key": os.getenv("OPENAI_API_KEY", ""),
        "openai_model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        "ollama_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/"),
        "ollama_model": os.getenv("OLLAMA_MODEL", "qwen2.5:14b"),
        "tesseract_cmd": os.getenv("TESSERACT_CMD", ""),
        "ocr_languages": os.getenv("OCR_LANGUAGES", "eng+chi_sim+chi_tra"),
        "input_dir": Path(os.getenv("INPUT_DIR", "./books")),
        "output_dir": Path(os.getenv("OUTPUT_DIR", "./output")),
        "chunk_chars": int(os.getenv("CHUNK_CHARS", "6000")),
        "chunk_overlap": int(os.getenv("CHUNK_OVERLAP", "500")),
        "ocr_mode": os.getenv("OCR_MODE", "auto").lower(),
        "ocr_min_text_chars": int(os.getenv("OCR_MIN_TEXT_CHARS", "80")),
        "max_chunks": int(os.getenv("MAX_CHUNKS_PER_RUN", "0")),
    }
